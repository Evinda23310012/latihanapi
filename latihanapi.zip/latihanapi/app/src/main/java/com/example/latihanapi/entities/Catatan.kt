package com.example.latihanapi.entities

data class Catatan(
    val  id: Int,
    val judul: String,
    val  isi: String
)
