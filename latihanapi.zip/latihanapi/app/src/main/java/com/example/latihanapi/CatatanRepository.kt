package com.example.latihanapi

interface CatatanRepository {
}