package com.example.latihanapi

object RetrofitClient {
}